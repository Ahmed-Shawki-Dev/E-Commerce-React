const DashboardCategoriesPage = () => {
  return (
    <div>DashboardCategoriesPage</div>
  )
}

export default DashboardCategoriesPage