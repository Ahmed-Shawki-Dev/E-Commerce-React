
const DashboardPage = () => {
  return (
    <div>
      Dashboard
    </div>
  );
};

export default DashboardPage;
