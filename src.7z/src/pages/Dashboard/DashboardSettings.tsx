const DashboardSettingsPage = () => {
  return (
    <div>DashboardSettingsPage</div>
  )
}

export default DashboardSettingsPage