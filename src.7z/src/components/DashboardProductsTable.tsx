import { yupResolver } from "@hookform/resolvers/yup";
import {
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  TableContainer,
  Image,
  Button,
  useDisclosure,
  useToast,
  Input,
  ModalFooter,
  Stack,
} from "@chakra-ui/react";
import TableSkeleton from "@/components/ui/TableSkeleton";
import { useForm, type SubmitHandler } from "react-hook-form";
import {
  useDeleteDashboardProductMutation,
  useEditDashboardProductMutation,
  useGetDashboardProductsQuery,
} from "@/app/services/apiSlice";
import { BASE_URL } from "@/config/index.config";
import type { EditProductForm, IProduct } from "@/interfaces";
import { Eye, PenLine, Trash2 } from "lucide-react";
import AlertModal from "./shared/AlertDialog";
import { useState } from "react";
import ModalDialog from "./shared/Modal";
import { editProductSchema } from "@/validation";
import InputErrorMessage from "./ui/InputErrorMessage";

const DashboardProductsTable = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<EditProductForm>({
    resolver: yupResolver(editProductSchema),
  });

  const onEditSubmit: SubmitHandler<EditProductForm> = async (data) => {
    const updatedProduct: IProduct = {
      ...productToUpdate,
      ...data,
    };

    await updateProduct({
      documentId: productToUpdate.documentId!,
      editedProduct: updatedProduct,
    });
  };

  const { isOpen, onOpen, onClose } = useDisclosure();
  const editModalDisclosure = useDisclosure();
  const toast = useToast();
  const { isLoading, data: products } = useGetDashboardProductsQuery({});
  const [deleteProduct, { isLoading: isProductRemove }] =
    useDeleteDashboardProductMutation();

  const [updateProduct] = useEditDashboardProductMutation();

  const [productToDelete, setProductToDelete] = useState("");
  const deleteProductHandler = (documentId: string) => {
    onOpen();
    setProductToDelete(documentId);
  };

  const [productToUpdate, setProductToUpdate] = useState<IProduct>({
    title: "",
    description: "",
    price: 0,
    categories: [],
    stock: 0,
    thumbnail: {
      url: "",
    },
  });

  if (isLoading) return <TableSkeleton />;
  return (
    <>
      <TableContainer overflowX="auto">
        <Table variant="simple">
          <Thead>
            <Tr>
              <Th>ID</Th>
              <Th>TITLE</Th>
              <Th>CATEGORY</Th>
              <Th>THUMBNAIL</Th>
              <Th>PRICE</Th>
              <Th>STOCK</Th>
              <Th>ACTION</Th>
            </Tr>
          </Thead>
          <Tbody>
            {products?.data.map((product: IProduct) => (
              <Tr>
                <Td>{product?.documentId}</Td>
                <Td>{product?.title}</Td>
                <Td>{product?.categories?.[0]?.title ?? ""}</Td>
                <Td>
                  <Image
                    src={`${BASE_URL}${product.thumbnail?.url}`}
                    boxSize="60px"
                    borderRadius="md"
                    objectFit="cover"
                    flexShrink={0}
                  />{" "}
                </Td>
                <Td>{product?.price}</Td>
                <Td>{product?.stock}</Td>
                <Td>
                  <Button mr={2}>
                    <Eye />
                  </Button>
                  <Button
                    mr={2}
                    onClick={() =>
                      deleteProductHandler(
                        product.documentId ? product.documentId : "",
                      )
                    }
                    isLoading={isProductRemove}
                  >
                    <Trash2 />
                  </Button>

                  <Button
                    onClick={() => {
                      setProductToUpdate({ ...product });
                      editModalDisclosure.onOpen();
                    }}
                  >
                    <PenLine />
                  </Button>
                </Td>
              </Tr>
            ))}
          </Tbody>
        </Table>
      </TableContainer>

      <AlertModal
        isOpen={isOpen}
        onClose={onClose}
        title="Delete Product"
        description="Are you sure you want to delete this product? This action cannot be undone."
        acceptTxt="Yes"
        rejectTxt="Cancel"
        onCLick={async () => {
          await deleteProduct(productToDelete);
          onClose();
          toast({
            title: "Product Deleted Successfully.",
            status: "success",
            duration: 2000,
            isClosable: true,
          });
        }}
      />

      <ModalDialog
        title="Edit The Product"
        isOpen={editModalDisclosure.isOpen}
        onClose={editModalDisclosure.onClose}
      >
        <Stack as="form" spacing={5} onSubmit={handleSubmit(onEditSubmit)}>
          <Stack>
            <Input
              placeholder="Enter Title"
              variant="flushed"
              {...register("title")}
            />
            <InputErrorMessage msg={errors?.title?.message} />
          </Stack>

          <Stack>
            <Input
              placeholder="Enter Category"
              variant="flushed"
              {...register("categories.0.title")}
            />
            <InputErrorMessage msg={errors?.categories?.[0]?.title?.message} />
          </Stack>

          <Stack>
            <Input
              placeholder="Enter price"
              variant="flushed"
              {...register("price")}
            />
            <InputErrorMessage msg={errors?.price?.message} />
          </Stack>

          <Stack>
            <Input
              placeholder="Enter Stock"
              variant="flushed"
              {...register("stock")}
            />
            <InputErrorMessage msg={errors?.stock?.message} />
          </Stack>

          <ModalFooter>
            <Button colorScheme="blue" mr={3} onClick={onClose}>
              Close
            </Button>
            <Button variant="ghost" type="submit" onClick={onClose}>
              Update
            </Button>
          </ModalFooter>
        </Stack>
      </ModalDialog>
    </>
  );
};

export default DashboardProductsTable;
