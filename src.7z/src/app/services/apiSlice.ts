import { BASE_URL } from "@/config/index.config";
import type { IProduct } from "@/interfaces";
import CookieService from "@/services/CookieService";
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

interface IResponse {
  data: IProduct[];
}

export const apiSlice = createApi({
  reducerPath: "api",
  tagTypes: ["Products"],
  baseQuery: fetchBaseQuery({ baseUrl: BASE_URL }),
  endpoints: (builder) => ({
    getDashboardProducts: builder.query<IResponse, unknown>({
      providesTags: ["Products"],
      query: () => {
        return {
          url: `/api/products?populate=thumbnail&populate=categories`,
        };
      },
    }),
    deleteDashboardProduct: builder.mutation({
      invalidatesTags: ["Products"],
      query: (documentId: string) => {
        return {
          url: `/api/products/${documentId}`,
          method: "DELETE",
          headers: {
            Authorization: `Bearer ${CookieService.get("jwt")}`,
          },
        };
      },
    }),
    editDashboardProduct: builder.mutation({
      query: ({
        documentId,
        editedProduct,
      }: {
        documentId: string;
        editedProduct: IProduct;
      }) => ({
        url: `/api/products/${documentId}`,
        method: "PATCH",
        body: editedProduct, 
        headers: {
          Authorization: `Bearer ${CookieService.get("jwt")}`,
        },
      }),
    }),
  }),
});

export const {
  useGetDashboardProductsQuery,
  useDeleteDashboardProductMutation,
  useEditDashboardProductMutation,
} = apiSlice;
