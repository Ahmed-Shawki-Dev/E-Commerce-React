export interface IProduct {
  documentId?: string | undefined;
  thumbnail?: {
    url: string;
  };
  title: string;
  description: string;
  price: number;
  categories?: ICategory[] | undefined;
  stock?: number;
}

interface ICategory {
  id?: number;
  documentId?: string;
  title: string;
}

export interface ILoginData {
  identifier: string;
  password: string;
}

export interface IUser {
  id?: number;
  username: string;
  email: string;
}

export interface ILoginResponse {
  jwt: string;
  user: IUser;
}

export interface ICart extends IProduct {
  qty: number;
}

export type EditProductForm = {
  title: string;
  price: number;
  stock: number;
  categories: ICategory[];
};
